BARTRADE-SIFRARNIK

Projekat sadrzi 815 artikala iz dostavljenog CSV sifrarnika.

POKRETANJE NA REPLIT.COM
1. Napravi novi Replit projekat (Node.js).
2. Otpakuj ZIP i otpremi SVE fajlove i folder assets u projekat.
3. Klikni Run. Aplikacija se pokrece preko npm start.
4. Otvori javni Replit URL na Android telefonu.

INSTALACIJA NA ANDROID
1. Otvori Replit URL u Chrome-u.
2. Otvori meni (tri tackice).
3. Izaberi „Install app“ ili „Add to Home screen“.
4. Ikonica Bartrade-sifrarnik pojavice se na pocetnom ekranu.

PRETRAGA
Pretraga radi odmah po sifri i nazivu artikla. Podrzava i unos dijela sifre/naziva.
Aplikacija ima PWA manifest i osnovni offline kes nakon prvog ucitavanja.

IZMJENA SIFRARNIKA
artikli.js je aktivni katalog koji aplikacija ucitava. artikli-original.csv je originalni
CSV prilog za referencu. Ako mijenjas katalog, azuriraj artikli.js u formatu:
window.ARTIKLI = [{"sifra":"123","ime":"Naziv artikla"}];
